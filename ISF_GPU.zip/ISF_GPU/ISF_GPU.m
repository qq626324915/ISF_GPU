% Author: Yuan Fang, Yongkang Gan
% E-mail: fangyuan_cugb@foxmail.com; gy_kavin809@126.com
% Descriptions:
      % Implementation of the Inverse Stokes Formula method, in which the 
	  % calculation process is improved and GPU parallel computing is incorporated.
	  % Marine gravity anomalies can be inverted from the geoid height undulation via this code.
      %      function [dat, nx, ny, xmin, xmax, ymin, ymax] = Grdread( filename)
	  %      is used to read the gridded data.
      %      function  Grdwrite( dat, filename, nx, ny, xmin, xmax, ymin, ymax)	  
	  %      is used to write the gridded data.  


clc;clear
tic
thelo=0.125; % the grid interval along the longitude direction (Deg)
thela=0.125; % the grid interval along the latitude direction (Deg)

% Read the gridded data of global geoid height undulation
[N, nx, ny, xmin, xmax, ymin, ymax] = Grdread( 'EGM008_global.grd');
x=xmin:((xmax-xmin)/(nx-1)):xmax;  % longitude coordinate vector of global data
y=ymin:((ymax-ymin)/(ny-1)):ymax;  % latitude coordinate vector of global data
[lo,la]=meshgrid(x,y);
% lo is the longitude coordinate gridded data of global data.
% la is the latitude coordinate gridded data of global data.
num_glo=0; % the number of the global geoid height undulation data
for i=1:ny
    for j=1:nx
        num_glo=num_glo+1;
        glo_N(num_glo)=N(i,j);   % glo_N is the vector of global geoid height undulation.
        glo_la(num_glo)=la(i,j); % glo_la is the latitude coordinate vector of global geoid height undulation.
        glo_lo(num_glo)=lo(i,j); % glo_lo is the longitude coordinate vector of global geoid height undulation.
    end
end
% Convert the above three vectors into GPU arrays
glo_N=gpuArray(glo_N);
glo_la=gpuArray(glo_la);
glo_lo=gpuArray(glo_lo);

% Read the gridded data of geoid height undulation of the study area
[com_dat, com_nx, com_ny, com_xmin, com_xmax, com_ymin, com_ymax] = Grdread('South_China_Sea.grd');
com_y=com_ymin:((com_ymax-com_ymin)/(com_ny-1)):com_ymax; % latitude coordinate vector of study area
com_x=com_xmin:((com_xmax-com_xmin)/(com_nx-1)):com_xmax; % longitude coordinate vector of study area
[xx,yy]=meshgrid(com_x,com_y);
% xx is the longitude coordinate gridded data of study area.
% yy is the latitude coordinate gridded data of study area.
mm=(com_xmin-xmin)/thelo+1:1:(com_xmin-xmin)/thelo+com_nx;
nn=(com_ymin-ymin)/thela+1:1:(com_ymin-ymin)/thela+com_ny;
[MM,NN]=meshgrid(mm,nn);
num_com=0; % the number of the geoid height undulation data of the study area (in the sea)
for i=1:com_ny
    for j=1:com_nx
        num_com=num_com+1;
        pos(num_com)=(NN(i,j)-1)*nx+MM(i,j);
        % the location (index) of the elements of the vector com_N (the vector of geoid height 
        % undulation of the study area) in the vector glo_N (the vector of global geoid height undulation)
        com_N(num_com)=com_dat(i,j); % com_N is the vector of geoid height undulation of the study area.
        com_la(num_com)=yy(i,j); % com_la is the latitude coordinate vector of geoid height undulation of the study area.
        com_lo(num_com)=xx(i,j); % com_lo is the longitude coordinate vector of geoid height undulation of the study area.
    end
end
% Convert the vectors com_N, com_la and com_lo into GPU arrays
com_N=gpuArray(com_N);
com_la=gpuArray(com_la);
com_lo=gpuArray(com_lo);

normal_g=9.797644656*ones(1,num_com);% the average gravity of the earth (m/s^2)
normal_g=gpuArray(normal_g); 

% calculate the marine gravity anomaly
com_Grav=zeros(1,num_com,'gpuArray'); % the marine gravity anomaly of the study area
for i=1:num_com
    zla=glo_la;zlo=glo_lo;zN=glo_N;
    zla(pos(i))=[];zlo(pos(i))=[];zN(pos(i))=[];
    Nq_Np=zN-com_N(i);
    Z_phin=sind((com_la(i)-zla)/2).^2+sind((com_lo(i)-zlo)/2).^2.*cosd(zla).*cosd(com_la(i));
    com_Grav(i)=sum((Nq_Np).*cosd(zla)./(4*Z_phin.^(3/2)));
end
R=6371393; % the average radius of the earth (m)
com_Grav=-1*normal_g.*com_N/R-deg2rad(thelo)*deg2rad(thela)/(4*pi*R)*normal_g.*com_Grav;
com_Grav=gather(com_Grav);

% output the results.
num=0;
for i=1:com_ny
    for j=1:com_nx
        num=num+1;
        cGr(i,j)=com_Grav(num)*100000;
    end
end
Grdwrite( cGr, 'G_South_China_Sea.grd.grd',com_nx, com_ny, com_xmin, com_xmax, com_ymin, com_ymax);


function [dat, nx, ny, xmin, xmax, ymin, ymax] = Grdread( filename)
% Read the gridded data
fp=fopen(filename,'r');
fscanf(fp,'%s',1);
nx=fscanf(fp,'%d',1);
ny=fscanf(fp,'%d',1);
xmin=fscanf(fp,'%g',1);
xmax=fscanf(fp,'%g',1);
ymin=fscanf(fp,'%g',1);
ymax=fscanf(fp,'%g',1);
zmin=fscanf(fp,'%g',1);
zmax=fscanf(fp,'%g',1);
for i=1:ny
    for j=1:nx
        dat(i,j)=fscanf(fp,'%g',1);
    end
end
fclose(fp);

end

function  Grdwrite( dat, filename, nx, ny, xmin, xmax, ymin, ymax)
% Output the gridded data
zmin=min(min(dat));
zmax=max(max(dat));
fp=fopen(filename,'w')
fprintf(fp,'DSAA\n');
fprintf(fp,'%d %d\n',nx,ny);
fprintf(fp,'%g %g\n',xmin,xmax);
fprintf(fp,'%g %g\n',ymin,ymax);
fprintf(fp,'%g %g\n',zmin,zmax);
for i=1:ny
    for j=1:nx
        fprintf(fp,'%g\n ',dat(i,j));
    end
end
fclose(fp);

end
