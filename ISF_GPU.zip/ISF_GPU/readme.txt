Name of the program: ISF_GPU.m

Title of the manuscript: A fast method for calculation of marine gravity anomaly

Author details: Yuan Fang, Jun Wang, Xiaohong Meng, Yongkang Gan, Hanhan Tang
                School of Geophysics and Information Technology, China University
                of Geosciences, Beijing 100083, China
			    
				Emails: fangyuan_cugb@foxmail.com(Yuan Fang)
			            wangjun5505@163.com(Jun Wang)
					    mxh@cugb.edu.cn(Xiaohong Meng)
			   		    gy_kavin809@126.com(Yongkang Gan)
					    3010180015@cugb.edu.cn(Hanhan Tang)